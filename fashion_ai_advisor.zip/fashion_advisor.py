from fastapi import FastAPI
from pydantic import BaseModel
import openai
import os

app = FastAPI()

openai.api_key = os.getenv("OPENAI_API_KEY")

class FashionRequest(BaseModel):
    occasion: str
    mood: str
    style: str

@app.post("/fashion-advice")
async def fashion_advice(req: FashionRequest):
    prompt = f"""You are a professional fashion stylist AI.
    Suggest 3 outfit ideas for the following inputs:
    Occasion: {req.occasion}
    Mood: {req.mood}
    Preferred Style: {req.style}

    For each outfit, explain why it works and suggest matching shoes & accessories."""

    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}]
        )
        advice = response["choices"][0]["message"]["content"]
        return {"advice": advice}
    except Exception as e:
        return {"error": str(e)}
